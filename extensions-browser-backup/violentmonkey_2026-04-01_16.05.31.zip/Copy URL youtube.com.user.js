// ==UserScript==
// @name        Copy URL youtube.com
// @namespace   Violentmonkey Scripts
// @match       https://www.youtube.com/watch*
// @version     1.0
// @author      -
// @description 1/4/2026, 3:52:57 pm
// @grant        GM_setClipboard
// ==/UserScript==

(() => {
              GM_setClipboard(window.location.href);
})()
